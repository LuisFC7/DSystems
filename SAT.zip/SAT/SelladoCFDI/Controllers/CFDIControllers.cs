using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text.Json;
using SchemasCFDI;
using System.Runtime.InteropServices;
using System.Linq.Expressions;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Xsl;
using CertReader;
using codingConvert;
using System.Text;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Security;
using System.Xml.XPath;





namespace SelladoCFDI.Controllers;

[ApiController]
// [Route("[controller]")]
[Route("api/[controller]")]

public class FacturacionController : ControllerBase
{
    [HttpPost]
    public IActionResult CFDIGeneration([FromBody] JsonElement jsonContract){

        int N=10;


        try{
            
            int elements = 0;

            //OBTENCION DE NUMERO DE ELEMENTOS DE UN ARRAY
            if(jsonContract.TryGetProperty("concepts", out var ne)){
                JsonElement conceptsList = jsonContract.GetProperty("concepts");

                if(conceptsList.ValueKind == JsonValueKind.Array){
                    elements = conceptsList.GetArrayLength();
                }
            }

            Comprobante receipt = new Comprobante();

            //INFORMACIÓN GLOBAL
            ComprobanteInformacionGlobal globalInformation = new ComprobanteInformacionGlobal();

            //CFDI RELACIONADOS
            ComprobanteCfdiRelacionados relatedCFDIS = new ComprobanteCfdiRelacionados();
            ComprobanteCfdiRelacionadosCfdiRelacionado relatedCFDI = new ComprobanteCfdiRelacionadosCfdiRelacionado();

            //EMISOR
            ComprobanteEmisor issuer = new ComprobanteEmisor();

            //RECEPTOR
            ComprobanteReceptor recipient = new ComprobanteReceptor();

            ComprobanteConcepto[] concepts = new ComprobanteConcepto[elements];
            ComprobanteConcepto concept = new ComprobanteConcepto();


           //IMPUESTOS CONCEPTOS
            ComprobanteImpuestos taxes = new ComprobanteImpuestos();
            

            //DATA COMPROBANTE CFDI
            if(jsonContract.TryGetProperty("receipt", out var genDat)){
                var receiptData = jsonContract.GetProperty("receipt");

                receipt.Version = receiptData.GetProperty("version").GetString();//required
                receipt.Fecha = receiptData.GetProperty("date").GetString();//required
                receipt.Sello = receiptData.GetProperty("seal").GetString();//required
                receipt.NoCertificado = receiptData.GetProperty("certicatedNumber").GetString();//required
                receipt.Certificado = receiptData.GetProperty("certificate").GetString();//required
                receipt.SubTotal = receiptData.GetProperty("subTotal").GetDecimal();//required
                receipt.Moneda = receiptData.GetProperty("currency").GetString();//required
                receipt.Total = receiptData.GetProperty("total").GetDecimal();//required
                receipt.TipoDeComprobante = receiptData.GetProperty("type").GetString();//required
                receipt.Exportacion =  receiptData.GetProperty("exportation").GetString();//required
                receipt.LugarExpedicion = receiptData.GetProperty("expeditionPlace").GetString();//required             
            }

            if(jsonContract.TryGetProperty("globalInformation", out var glIn)){
                var globalInf = jsonContract.GetProperty("globalInformation");

                globalInformation.Periodicidad = globalInf.GetProperty("periodicity").GetString();//required
                globalInformation.Meses = globalInf.GetProperty("months").GetString();//required
                globalInformation.Año = Convert.ToInt16(globalInf.GetProperty("year").GetString());//required
                         
            }

            // //CFDI RELACIONADO
            // if(jsonContract.TryGetProperty("relatedCDFDI", out var rCFDI)){
            //     var relCFDI = jsonContract.GetProperty("relatedCFDI");

            //     relatedCFDI.UUID = relCFDI.GetProperty("UUID").GetString();//required
         
            // }

            // if(jsonContract.TryGetProperty("relatedCDFDIS", out var rsCFDI)){
            //     var relCFDIS = jsonContract.GetProperty("relatedCFDIS");

            //     relatedCFDIS.TipoRelacion = relCFDIS.GetProperty("relationType").GetString();//required
                        
            // }

            //EMISOR
            if(jsonContract.TryGetProperty("issuer", out var emi)){
                var issu = jsonContract.GetProperty("issuer");

                issuer.Rfc = issu.GetProperty("rfc").GetString();//required
                issuer.Nombre = issu.GetProperty("name").GetString();//required
                issuer.RegimenFiscal = issu.GetProperty("fiscalRegime").GetString();//required
                        
            }
            
            //RECEPTOR
            if(jsonContract.TryGetProperty("recipient", out var recep)){
                var recip = jsonContract.GetProperty("recipient");

                recipient.Rfc = recip.GetProperty("rfc").GetString();//required
                recipient.Nombre = recip.GetProperty("name").GetString();//required
                recipient.DomicilioFiscalReceptor = recip.GetProperty("fiscalRecipientAddress").GetString();//required
                recipient.RegimenFiscalReceptor = recip.GetProperty("fiscalRegimeRecipient").GetString();//required
                recipient.UsoCFDI = recip.GetProperty("CFDIUse").GetString();
                        
            }


            //SOLO SE LEE UN CONCEPTO
            if(jsonContract.TryGetProperty("concepts", out var conc)){
                JsonElement conceptsList = jsonContract.GetProperty("concepts");

                if(conceptsList.ValueKind == JsonValueKind.Array){

                    foreach(var conceptElement in conceptsList.EnumerateArray()){
                        //Iterar sobre los concepto
                        concept.ClaveProdServ = conceptElement.GetProperty("rfc").GetString();//required
                        concept.Cantidad = conceptElement.GetProperty("name").GetDecimal();//required
                        concept.ClaveUnidad = conceptElement.GetProperty("unitKey").GetString();//required
                        concept.Descripcion = conceptElement.GetProperty("description").GetString();//required
                        concept.ValorUnitario = conceptElement.GetProperty("unityValue").GetDecimal();
                        concept.Importe = conceptElement.GetProperty("amount").GetDecimal();
                        concept.ObjetoImp = conceptElement.GetProperty("impObject").GetString();
                        

                        concepts.Append(concept);

                    }

                }

                receipt.Emisor = issuer;
                receipt.Receptor = recipient;
                receipt.Conceptos = concepts;

                serializeObject(receipt,"CFDI.xml");
        
            }




            return Ok(receipt);

        }catch (Exception ex){
            return StatusCode(500, $"Error: {ex.Message}");
        }


    static void serializeObject(Comprobante nameObject, string nameDocument){
        XmlSerializer comprobanteXML = new XmlSerializer(typeof(ContainerSpace.Container));
            string pathXML = nameDocument;
            string sxml = "";

            using (var sww = new StringWriterWithEncoding(Encoding.UTF8)){
                using(XmlWriter writter = XmlWriter.Create(sww)){
                    comprobanteXML.Serialize(writter,nameObject);
                    sxml = sww.ToString();
                }
            }


            System.IO.File.WriteAllText(pathXML,sxml);
    }

    }
}

