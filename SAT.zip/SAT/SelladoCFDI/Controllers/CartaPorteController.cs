using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text.Json;
using Schemas;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Xml;
using ContainerSpace;
using System.Xml.Linq;

using System.Xml.Xsl;


using System.Reflection.Metadata;

using CertReader;
using codingConvert;
using System.Text;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Security;
using System.Xml.XPath;



namespace SelladoCFDI.Controllers;

[ApiController]
// [Route("[controller]")]
[Route("api/[controller]")]

public class CartaPorteController : ControllerBase
{
    [HttpPost]
    public IActionResult CartaPorte([FromBody] JsonElement jsonDictionary){

        try{

            string pathCer = @"CSD_Pruebas_CFDI_SPR190613I52.cer";
            string inicio, final,serie,numero;
            SelloDigital.LeerCER(pathCer, out inicio, out final, out serie, out numero);

            //"NUMERO SAVED THE CER"
            Console.WriteLine($"Inicio: {inicio}, Final: {final}, Serie: {serie}, Numero: {numero}");
            // string pathCer = @"CSD_Pruebas_CFDI_SPR190613I52.cer";
            string pathKey = @"CSD_Pruebas_CFDI_SPR190613I52.key";
            string clavePrivada = "12345678a";

            // string numeroCertificado, aa, b, c;


            // SelloDigital.leerCER(pathCer,out aa, out b, out c, out numeroCertificado);
           
            CartaPorte cartaPorte = new CartaPorte();

            CartaPorteUbicacion cartaPorteUbicacionOrigen = new CartaPorteUbicacion();
            CartaPorteUbicacionDomicilio cartaPorteDomicilioOrigen = new CartaPorteUbicacionDomicilio();

            CartaPorteUbicacion cartaPorteUbicacionDestino = new CartaPorteUbicacion();
            CartaPorteUbicacionDomicilio cartaPorteDomicilioDestino = new CartaPorteUbicacionDomicilio();

            CartaPorteMercancias cartaPorteMercancias = new CartaPorteMercancias();

            CartaPorteMercanciasMercancia cartaPorteMercanciasMercancia = new CartaPorteMercanciasMercancia();
            List<CartaPorteMercanciasMercancia> mercanciasSaved = new List<CartaPorteMercanciasMercancia>();
            List<JsonElement> savedMerch = new List<JsonElement>();


            // // AUTOTRANSPORTE

            CartaPorteMercanciasAutotransporte cartaPorteMercanciasAutotransporte = new CartaPorteMercanciasAutotransporte();
            CartaPorteMercanciasAutotransporteIdentificacionVehicular cartaPorteMercanciasAutotransporteIdentificacionVehicular = new CartaPorteMercanciasAutotransporteIdentificacionVehicular();
            CartaPorteMercanciasAutotransporteSeguros cartaPorteMercanciasAutotransporteSeguros = new CartaPorteMercanciasAutotransporteSeguros();
            CartaPorteMercanciasAutotransporteRemolque cartaPorteMercanciasAutotransporteRemolque = new CartaPorteMercanciasAutotransporteRemolque();

            //Operadores
            CartaPorteTiposFigura cartaPorteTiposFiguraOp = new CartaPorteTiposFigura();
            CartaPorteTiposFiguraDomicilio cartaPorteTiposFiguraDomicilioOp = new CartaPorteTiposFiguraDomicilio();

            //PROPIETARIO
            CartaPorteTiposFigura cartaPorteTiposFiguraPr = new CartaPorteTiposFigura();
            CartaPorteTiposFiguraDomicilio cartaPorteTiposFiguraDomicilioPr = new CartaPorteTiposFiguraDomicilio();


            //LLAMADA A CONTENEDOR
            ContainerSpace.Container contenedor = new ContainerSpace.Container();


            // DATOS GENERALES

            if(jsonDictionary.TryGetProperty("general", out var genDat)){
                var generalData = jsonDictionary.GetProperty("general");

                cartaPorte.Version = generalData.GetProperty("Version").GetString();
                cartaPorte.IdCCP = generalData.GetProperty("IdCCP").GetString();
                cartaPorte.TranspInternac = generalData.GetProperty("TranspInternac").GetString();
                cartaPorte.TotalDistRec = generalData.GetProperty("TotalDistRec").GetDecimal();
                cartaPorte.EntradaSalidaMerc = generalData.GetProperty("EntradaSalidaMerc").GetString();
                cartaPorte.PaisOrigenDestino = generalData.GetProperty("PaisOrigenDestino").GetString();              
            }
            


            if (jsonDictionary.TryGetProperty("ubicacionOrigen", out var ubiOriDat)){

                var ubicacionOrigenData = jsonDictionary.GetProperty("ubicacionOrigen");

                cartaPorteUbicacionOrigen.TipoUbicacion = ubicacionOrigenData.GetProperty("TipoUbicacion").GetString();

                cartaPorteDomicilioOrigen.Calle = ubicacionOrigenData.GetProperty("Calle").GetString();
                cartaPorteDomicilioOrigen.NumeroExterior = ubicacionOrigenData.GetProperty("NumeroExterior").GetString();
                cartaPorteDomicilioOrigen.NumeroInterior = ubicacionOrigenData.GetProperty("NumeroInterior").GetString();
                cartaPorteDomicilioOrigen.Colonia = ubicacionOrigenData.GetProperty("Colonia").GetString();
                cartaPorteDomicilioOrigen.CodigoPostal= ubicacionOrigenData.GetProperty("CodigoPostal").GetString();
                cartaPorteDomicilioOrigen.Referencia = ubicacionOrigenData.GetProperty("Referencia").GetString();
                cartaPorteDomicilioOrigen.Localidad = ubicacionOrigenData.GetProperty("Localidad").GetString();
                cartaPorteDomicilioOrigen.Municipio = ubicacionOrigenData.GetProperty("Municipio").GetString();
                cartaPorteDomicilioOrigen.Estado = ubicacionOrigenData.GetProperty("Estado").GetString();

                cartaPorteUbicacionOrigen.RFCRemitenteDestinatario = ubicacionOrigenData.GetProperty("RFCRemitenteDestinatario").GetString();
                cartaPorteUbicacionOrigen.NombreRemitenteDestinatario = ubicacionOrigenData.GetProperty("NombreRemitenteDestinatario").GetString();
                cartaPorteUbicacionOrigen.FechaHoraSalidaLlegada = ubicacionOrigenData.GetProperty("FechaHoraSalidaLlegada").GetString();

                // string extractDate = ubicacionOrigenData.GetProperty("FechaHoraSalidaLlegada").ToString();
                // if(DateTime.TryParse(extractDate, out DateTime fechaHoraSalidaLlegada)){
                //     cartaPorteUbicacionOrigen.FechaHoraSalidaLlegada = fechaHoraSalidaLlegada;
                // }

            }
            

            if (jsonDictionary.TryGetProperty("ubicacionDestino", out var ubiDesDat)){

                var ubicacionDestinoData = jsonDictionary.GetProperty("ubicacionDestino");

                cartaPorteUbicacionDestino.TipoUbicacion = ubicacionDestinoData.GetProperty("TipoUbicacion").GetString();

                cartaPorteDomicilioDestino.Calle = ubicacionDestinoData.GetProperty("Calle").GetString();
                cartaPorteDomicilioDestino.NumeroExterior = ubicacionDestinoData.GetProperty("NumeroExterior").GetString();
                cartaPorteDomicilioDestino.NumeroInterior = ubicacionDestinoData.GetProperty("NumeroInterior").GetString();
                cartaPorteDomicilioDestino.Colonia = ubicacionDestinoData.GetProperty("Colonia").GetString();
                cartaPorteDomicilioDestino.CodigoPostal= ubicacionDestinoData.GetProperty("CodigoPostal").GetString();
                cartaPorteDomicilioDestino.Referencia = ubicacionDestinoData.GetProperty("Referencia").GetString();
                cartaPorteDomicilioDestino.Localidad = ubicacionDestinoData.GetProperty("Localidad").GetString();
                cartaPorteDomicilioDestino.Municipio = ubicacionDestinoData.GetProperty("Municipio").GetString();
                cartaPorteDomicilioDestino.Estado = ubicacionDestinoData.GetProperty("Estado").GetString();

                cartaPorteUbicacionDestino.RFCRemitenteDestinatario = ubicacionDestinoData.GetProperty("RFCRemitenteDestinatario").GetString();
                cartaPorteUbicacionDestino.NombreRemitenteDestinatario = ubicacionDestinoData.GetProperty("NombreRemitenteDestinatario").GetString();
                cartaPorteUbicacionDestino.FechaHoraSalidaLlegada = ubicacionDestinoData.GetProperty("FechaHoraSalidaLlegada").GetString();


                // string extractDate = ubicacionDestinoData.GetProperty("FechaHoraSalidaLlegada").ToString();
                // if(DateTime.TryParse(extractDate, out DateTime fechaHoraSalidaLlegada)){
                //     cartaPorteUbicacionDestino.FechaHoraSalidaLlegada = fechaHoraSalidaLlegada;
                // }
            }


            // MERCANCIAS GENERAL
            if (jsonDictionary.TryGetProperty("mercanciaGeneral", out var merGenDat)){

                var mercanciaGeneralData = jsonDictionary.GetProperty("mercanciaGeneral");

                // CartaPorteMercancias cartaPorteMercancias = new CartaPorteMercancias();
                cartaPorteMercancias.PesoBrutoTotal = mercanciaGeneralData.GetProperty("PesoBrutoTotal").GetDecimal();
                cartaPorteMercancias.UnidadPeso = mercanciaGeneralData.GetProperty("UnidadPeso").GetString();
                cartaPorteMercancias.NumTotalMercancias = mercanciaGeneralData.GetProperty("NumTotalMercancias").GetInt32();

            }

            //MERCANCIAS
            if (jsonDictionary.TryGetProperty("mercancias", out var mercDat)){

                JsonElement mercanciasList = jsonDictionary.GetProperty("mercancias");

                if(mercanciasList.ValueKind == JsonValueKind.Array){


                    foreach(var mercanciaElement in mercanciasList.EnumerateArray()){

                        // CartaPorteMercanciasMercancia cartaPorteMercanciasMercancia = new CartaPorteMercanciasMercancia();
                        cartaPorteMercanciasMercancia.BienesTransp = mercanciaElement.GetProperty("BienesTransp").GetString();
                        cartaPorteMercanciasMercancia.Descripcion = mercanciaElement.GetProperty("Descripcion").GetString();
                        cartaPorteMercanciasMercancia.ClaveUnidad = mercanciaElement.GetProperty("ClaveUnidad").GetString();
                        cartaPorteMercanciasMercancia.Unidad = mercanciaElement.GetProperty("Unidad").GetString();
                        cartaPorteMercanciasMercancia.MaterialPeligroso = mercanciaElement.GetProperty("MaterialPeligroso").GetString();
                        cartaPorteMercanciasMercancia.PesoEnKg = mercanciaElement.GetProperty("PesoEnKg").GetDecimal();
                        cartaPorteMercanciasMercancia.ValorMercancia = mercanciaElement.GetProperty("ValorMercancia").GetDecimal();
                        cartaPorteMercanciasMercancia.Moneda = mercanciaElement.GetProperty("Moneda").GetString();
                        cartaPorteMercanciasMercancia.Cantidad = mercanciaElement.GetProperty("Cantidad").GetDecimal();


                        savedMerch.Add(mercanciaElement);
                        contenedor.cartaPorteMercanciasMercancias.Add(cartaPorteMercanciasMercancia);

                    }
                }

            }


            //AUTOTRANSPORTE
            if (jsonDictionary.TryGetProperty("autotransporte", out var autoTransDat)){

                var autotransporteData = jsonDictionary.GetProperty("autotransporte");


                cartaPorteMercanciasAutotransporte.PermSCT = autotransporteData.GetProperty("PermSCT").GetString();
                cartaPorteMercanciasAutotransporte.NumPermisoSCT = autotransporteData.GetProperty("NumPermisoSCT").GetString();
                cartaPorteMercanciasAutotransporteSeguros.AseguraRespCivil = autotransporteData.GetProperty("AseguraRespCivil").GetString();
                cartaPorteMercanciasAutotransporteSeguros.PolizaRespCivil = autotransporteData.GetProperty("PolizaRespCivil").GetString();
                cartaPorteMercanciasAutotransporteIdentificacionVehicular.ConfigVehicular = autotransporteData.GetProperty("ConfigVehicular").GetString();
                cartaPorteMercanciasAutotransporteIdentificacionVehicular.PesoBrutoVehicular = autotransporteData.GetProperty("PesoBrutoVehicular").GetDecimal();
                cartaPorteMercanciasAutotransporteIdentificacionVehicular.PlacaVM = autotransporteData.GetProperty("PlacaVM").GetString();
                cartaPorteMercanciasAutotransporteIdentificacionVehicular.AnioModeloVM = autotransporteData.GetProperty("AnioModeloVM").GetInt32();
                cartaPorteMercanciasAutotransporteRemolque.SubTipoRem = autotransporteData.GetProperty("SubTipoRem").GetString();
                cartaPorteMercanciasAutotransporteRemolque.Placa = autotransporteData.GetProperty("Placa").GetString();
            }

            // OPERADORES
            if (jsonDictionary.TryGetProperty("operadores", out var operatorDat)){
                var operadoresData = jsonDictionary.GetProperty("operadores");


                cartaPorteTiposFiguraOp.TipoFigura = operadoresData.GetProperty("TipoFigura").GetString();
                cartaPorteTiposFiguraOp.RFCFigura = operadoresData.GetProperty("RFCFigura").GetString();
                cartaPorteTiposFiguraOp.NombreFigura = operadoresData.GetProperty("NombreFigura").GetString();
                cartaPorteTiposFiguraOp.NumLicencia = operadoresData.GetProperty("NumLicencia").GetString();
                cartaPorteTiposFiguraOp.ResidenciaFiscalFigura = operadoresData.GetProperty("ResidenciaFiscalFigura").GetString();
                cartaPorteTiposFiguraDomicilioOp.Calle = operadoresData.GetProperty("Calle").GetString();
                cartaPorteTiposFiguraDomicilioOp.NumeroExterior = operadoresData.GetProperty("NumeroExterior").GetString();
                cartaPorteTiposFiguraDomicilioOp.NumeroInterior = operadoresData.GetProperty("NumeroInterior").GetString();
                cartaPorteTiposFiguraDomicilioOp.Colonia = operadoresData.GetProperty("Colonia").GetString();
                cartaPorteTiposFiguraDomicilioOp.CodigoPostal  = operadoresData.GetProperty("CodigoPostal").GetString();
                cartaPorteTiposFiguraDomicilioOp.Referencia = operadoresData.GetProperty("Referencia").GetString();
                cartaPorteTiposFiguraDomicilioOp.Localidad = operadoresData.GetProperty("Localidad").GetString();
                cartaPorteTiposFiguraDomicilioOp.Municipio = operadoresData.GetProperty("Municipio").GetString();
                cartaPorteTiposFiguraDomicilioOp.Estado = operadoresData.GetProperty("Estado").GetString();
                cartaPorteTiposFiguraDomicilioOp.Pais = operadoresData.GetProperty("Pais").GetString();
            }


            // //PROPIETARIO
            if (jsonDictionary.TryGetProperty("propietario", out var propietarioDat)){
                var propietarioData = jsonDictionary.GetProperty("propietario");


                cartaPorteTiposFiguraPr.TipoFigura = propietarioData.GetProperty("TipoFigura").GetString();
                cartaPorteTiposFiguraPr.RFCFigura = propietarioData.GetProperty("RFCFigura").GetString();
                cartaPorteTiposFiguraPr.NombreFigura = propietarioData.GetProperty("NombreFigura").GetString();
                cartaPorteTiposFiguraPr.NumLicencia = propietarioData.GetProperty("NumLicencia").GetString();
                cartaPorteTiposFiguraPr.ResidenciaFiscalFigura = propietarioData.GetProperty("ResidenciaFiscalFigura").GetString();
                cartaPorteTiposFiguraDomicilioPr.Calle = propietarioData.GetProperty("Calle").GetString();
                cartaPorteTiposFiguraDomicilioPr.NumeroExterior = propietarioData.GetProperty("NumeroExterior").GetString();
                cartaPorteTiposFiguraDomicilioPr.NumeroInterior = propietarioData.GetProperty("NumeroInterior").GetString();
                cartaPorteTiposFiguraDomicilioPr.Colonia = propietarioData.GetProperty("Colonia").GetString();
                cartaPorteTiposFiguraDomicilioPr.CodigoPostal  = propietarioData.GetProperty("CodigoPostal").GetString();
                cartaPorteTiposFiguraDomicilioPr.Referencia = propietarioData.GetProperty("Referencia").GetString();
                cartaPorteTiposFiguraDomicilioPr.Localidad = propietarioData.GetProperty("Localidad").GetString();
                cartaPorteTiposFiguraDomicilioPr.Municipio = propietarioData.GetProperty("Municipio").GetString();
                cartaPorteTiposFiguraDomicilioPr.Estado = propietarioData.GetProperty("Estado").GetString();
                cartaPorteTiposFiguraDomicilioPr.Pais = propietarioData.GetProperty("Pais").GetString();
            }


            // //LLAMADA A CONTENEDOR
            // ContainerSpace.Container contenedor = new ContainerSpace.Container();

            contenedor.CartaPorte=cartaPorte;

            contenedor.cartaPorteUbicacionOrigen = cartaPorteUbicacionOrigen;
            contenedor.cartaPorteDomicilioOrigen = cartaPorteDomicilioOrigen;

            contenedor.cartaPorteUbicacionDestino = cartaPorteUbicacionDestino;
            contenedor.cartaPorteDomicilioDestino = cartaPorteDomicilioDestino;

            contenedor.cartaPorteMercancias = cartaPorteMercancias;

            contenedor.cartaPorteMercanciasAutotransporte = cartaPorteMercanciasAutotransporte;
            contenedor.cartaPorteMercanciasAutotransporteIdentificacionVehicular = cartaPorteMercanciasAutotransporteIdentificacionVehicular;
            contenedor.cartaPorteMercanciasAutotransporteSeguros = cartaPorteMercanciasAutotransporteSeguros;
            contenedor.cartaPorteMercanciasAutotransporteRemolque = cartaPorteMercanciasAutotransporteRemolque;

            contenedor.cartaPorteTiposFiguraOp = cartaPorteTiposFiguraOp;
            contenedor.cartaPorteTiposFiguraDomicilioOp = cartaPorteTiposFiguraDomicilioOp;

            contenedor.cartaPorteTiposFiguraPr = cartaPorteTiposFiguraPr;
            contenedor.cartaPorteTiposFiguraDomicilioPr = cartaPorteTiposFiguraDomicilioPr; 

            //SERIALIZACIÓN
            XmlSerializer comprobanteXML = new XmlSerializer(typeof(ContainerSpace.Container));
            string pathXML = "CCP.xml";
            string sxml = "";

            using (var sww = new StringWriterWithEncoding(Encoding.UTF8)){
                using(XmlWriter writter = XmlWriter.Create(sww)){
                    comprobanteXML.Serialize(writter,contenedor);
                    sxml = sww.ToString();
                }
            }


            System.IO.File.WriteAllText(pathXML,sxml);

            // keyGenerator();

            Console.WriteLine(KeyGenerator());

            

            //GENERACIÓN DE CADENA.


            // try{
            //     // CREAR CADENA ORIGINAL
            //     string originalCad = "";
            //     string pathXSLT = @"cadenaoriginal_4_0.xslt";
            //     StreamReader reader = new StreamReader(@"C:\Users\SISTEMAS\source\repos\cfdi40\xml\cfdi.xml"); //comprobante
            //     XPathDocument myXPathDoc = new XPathDocument(reader);

            //     XslCompiledTransform transformated = new XslCompiledTransform();
            //     Console.WriteLine("AQUIIIIIIII");
            //     transformated.Load(pathXSLT);
            //     using (StringWriter sw = new StringWriter())
            //     using (XmlWriter xwo = XmlWriter.Create(sw, transformated.OutputSettings)){
            //         transformated.Transform(pathXML, xwo);
            //         originalCad = sw.ToString();
            //     }

            // }
            // catch (Exception ex)
            // {
            //     Console.WriteLine($"Error en la transformación XSLT: {ex.Message}");
            // }

            // SelloDigital selloDigital = new SelloDigital();

            // contenedor.certificado = selloDigital.Certificado(pathCer);
            // contenedor.sello = selloDigital.Sellar(originalCad, pathKey, clavePrivada);


            // //ultima serialización   
            // XmlSerializer CCPXML = new XmlSerializer(typeof(ContainerSpace.Container));
            // string pathXMLC = "CCP.xml";
            // string sxmlC = "";

            // using (var sww = new StringWriter()){
            //     using(XmlWriter writter = XmlWriter.Create(sww)){
            //         CCPXML.Serialize(writter,contenedor);
            //         sxmlC = sww.ToString();
            //     }
            // }

            // System.IO.File.WriteAllText(pathXMLC,sxmlC);

            return Ok(savedMerch);

        }catch (Exception ex){
            return StatusCode(500, $"Error: {ex.Message}");
        }




        // Primera Versión
        static string KeyGenerator(){


            StreamReader reader = new StreamReader("CCP.xml");
            XPathDocument XpathDoc = new XPathDocument(reader);

            XslCompiledTransform XTrans = new XslCompiledTransform();
            XTrans.Load(@"CartaPorte30.xslt");

            StringWriter str = new StringWriter();
            XmlTextWriter writer = new XmlTextWriter(str);


            XTrans.Transform(XpathDoc,null,writer);

            string result = str.ToString();

            return result;
        }        
        
    }
}

   
[ApiController]
[Route("api/[controller]")]
public class SaludoController : ControllerBase
{
    [HttpGet]
    public IActionResult Saludar()
    {
        return Ok("¡Hola desde tu primer endpoint!");
    }
}