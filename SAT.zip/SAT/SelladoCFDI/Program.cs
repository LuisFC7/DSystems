using SelladoCFDI.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(
    c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Nombre de tu API",
        Version = "v1"
    });
}
);

var app = builder.Build();

// app.MapGet("/", () =>
// {
//     var controller = new SaludoController();
//     return controller.Saludar();
// });

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/", SaludoAction);

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

IActionResult SaludoAction()
{
    var controller = new SaludoController();
    return controller.Saludar();
}