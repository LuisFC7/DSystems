namespace certificados{

	public class CertificadoProvider
	{
    		public static string ObtenerCertificado()
    		{
        		return "Certificado Obtenido";
   		 }

    		public static string ObtenerSello()
    		{
        		return "Sello Obtenido";
    		}
	}

}
