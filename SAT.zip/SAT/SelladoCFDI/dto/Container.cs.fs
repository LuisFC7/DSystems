using System.Security;


class General {
    public string Version;
    
}

class InputCartaPorte {
    
}