using System.Security;
using System.Security.Cryptography.X509Certificates;
using Schemas;
using certificados;
using System.Xml.Serialization;

namespace ContainerSpace{
    public class Container{

        // [XmlElement(Namespace="http://www.sat.gob.mx/CartaPorte30")]
        public CartaPorte CartaPorte { get; set; }

        public CartaPorteUbicacion cartaPorteUbicacionOrigen { get; set; }
        public CartaPorteUbicacionDomicilio cartaPorteDomicilioOrigen { get; set; }

        public CartaPorteUbicacion cartaPorteUbicacionDestino { get; set; }
        public CartaPorteUbicacionDomicilio cartaPorteDomicilioDestino { get; set; }

        public CartaPorteMercancias cartaPorteMercancias { get; set; }
        public CartaPorteMercanciasMercancia cartaPorteMercanciasMercancia { get; set; }


        public CartaPorteMercanciasAutotransporte cartaPorteMercanciasAutotransporte { get; set; }
        public CartaPorteMercanciasAutotransporteIdentificacionVehicular cartaPorteMercanciasAutotransporteIdentificacionVehicular { get; set; }
        public CartaPorteMercanciasAutotransporteSeguros cartaPorteMercanciasAutotransporteSeguros { get; set; }
        public CartaPorteMercanciasAutotransporteRemolque cartaPorteMercanciasAutotransporteRemolque { get; set; }

        public CartaPorteTiposFigura cartaPorteTiposFiguraOp { get; set; }
        public CartaPorteTiposFiguraDomicilio cartaPorteTiposFiguraDomicilioOp { get; set; }

        public CartaPorteTiposFigura cartaPorteTiposFiguraPr { get; set; }
        public CartaPorteTiposFiguraDomicilio cartaPorteTiposFiguraDomicilioPr { get; set; }

        public List<CartaPorteMercanciasMercancia> cartaPorteMercanciasMercancias { get; set; }

        public string certificado {get; set;}
        public string sello {get; set;}



        public Container(){
            CartaPorte = new CartaPorte();

            cartaPorteUbicacionOrigen = new CartaPorteUbicacion();
            cartaPorteDomicilioOrigen = new CartaPorteUbicacionDomicilio();

            cartaPorteUbicacionDestino = new CartaPorteUbicacion();
            cartaPorteDomicilioDestino = new CartaPorteUbicacionDomicilio();

            cartaPorteMercancias = new CartaPorteMercancias();
            cartaPorteMercanciasMercancia = new CartaPorteMercanciasMercancia();

            cartaPorteMercanciasAutotransporte = new CartaPorteMercanciasAutotransporte();
            cartaPorteMercanciasAutotransporteIdentificacionVehicular = new CartaPorteMercanciasAutotransporteIdentificacionVehicular();
            cartaPorteMercanciasAutotransporteSeguros = new CartaPorteMercanciasAutotransporteSeguros();
            cartaPorteMercanciasAutotransporteRemolque = new CartaPorteMercanciasAutotransporteRemolque();

            cartaPorteTiposFiguraOp = new CartaPorteTiposFigura();
            cartaPorteTiposFiguraDomicilioOp = new CartaPorteTiposFiguraDomicilio();

            cartaPorteTiposFiguraPr = new CartaPorteTiposFigura();
            cartaPorteTiposFiguraDomicilioPr = new CartaPorteTiposFiguraDomicilio();

            cartaPorteMercanciasMercancias = new List<CartaPorteMercanciasMercancia>();

            // certificado = CertificadoProvider.ObtenerCertificado();
            // sello = CertificadoProvider.ObtenerSello();

        

        }
    }

}
