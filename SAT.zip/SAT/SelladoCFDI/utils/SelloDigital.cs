using System;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.IO;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;


using System.Runtime.InteropServices;
using Org.BouncyCastle.Crypto.Parameters;


namespace CertReader{

    public class SelloDigital
    {
        public static bool LeerCER(string nombreArchivo, out string inicio, out string final, out string serie, out string numero)
        {
            inicio = final = serie = numero = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(nombreArchivo))
                    return false;

                X509Certificate2 objCert = new X509Certificate2(nombreArchivo);
                StringBuilder objSB = new StringBuilder("Detalle del certificado: \n\n");

                //Detalle
                objSB.AppendLine("Persona = " + objCert.Subject);
                objSB.AppendLine("Emisor = " + objCert.Issuer);
                objSB.AppendLine("Válido desde = " + objCert.NotBefore.ToString());
                inicio = objCert.NotBefore.ToString();
                objSB.AppendLine("Válido hasta = " + objCert.NotAfter.ToString());
                final = objCert.NotAfter.ToString();
                objSB.AppendLine("Tamaño de la clave = " + objCert.PublicKey.Key.KeySize.ToString());
                objSB.AppendLine("Número de serie = " + objCert.SerialNumber);
                serie = objCert.SerialNumber.ToString();

                objSB.AppendLine("Hash = " + objCert.Thumbprint);

                string tNumero = "", rNumero = "", tNumero2 = "";

                int X;
                if (serie.Length >= 2)
                {
                    foreach (char c in serie)
                    {
                        if (char.IsDigit(c))
                            tNumero += c;
                    }

                    for (X = 1; X < tNumero.Length; X += 2)
                    {
                        tNumero2 = tNumero.Substring(0, X);
                        rNumero = rNumero + tNumero2.Substring(tNumero2.Length - 1, 1);
                    }

                    numero = rNumero;
                }

                return DateTime.Now < objCert.NotAfter && DateTime.Now > objCert.NotBefore;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al leer el archivo CER: {ex.Message}");
                return false;
            }
        }


        public string Certificado(string ArchivoCER){
            byte[] Certificado = File.ReadAllBytes(ArchivoCER);
            return Base64_Encode(Certificado);
        }

        public string Certificado(byte[] ArchivoCER)
        {
            return Base64_Encode(ArchivoCER);
        }
        string Base64_Encode(byte[] str)
        {
            return Convert.ToBase64String(str);
        }
        byte[] Base64_Decode(string str)
        {
            try
            {
                byte[] decbuff = Convert.FromBase64String(str);
                return decbuff;
            }
            catch
            {
                { return null; }
            }
        }

        
        public string Sellar(string CadenaOriginal, string ArchivoClavePrivada, string lPassword)
        {
            byte[] ClavePrivada = File.ReadAllBytes(ArchivoClavePrivada);
            byte[] bytesFirmados = null;
            byte[] bCadenaOriginal = Encoding.UTF8.GetBytes(CadenaOriginal);

            SecureString lSecStr = new SecureString();
            SHA256Managed sham = new SHA256Managed();
            // SHA1Managed sham = new SHA1Managed(); versión 3.2
            lSecStr.Clear();

            foreach (char c in lPassword.ToCharArray())
                lSecStr.AppendChar(c);

            RSACryptoServiceProvider lrsa = DecodeEncryptedPrivateKeyInfo(ClavePrivada, lSecStr);
            bCadenaOriginal = Encoding.UTF8.GetBytes(CadenaOriginal);
            try
            {
                bytesFirmados = lrsa.SignData(Encoding.UTF8.GetBytes(CadenaOriginal), sham);
            }
            catch (NullReferenceException ex)
            {
                throw new NullReferenceException("Clave privada incorrecta, revisa que la clave que escribes corresponde a los sellos digitales cargados");
            }
            string sellodigital = Convert.ToBase64String(bytesFirmados);
            return sellodigital;
        }

        private RSACryptoServiceProvider DecodeEncryptedPrivateKeyInfo(byte[] encryptedBytes, SecureString password)
        {
            using (MemoryStream ms = new MemoryStream(encryptedBytes))
            {
                using (TextReader privateKeyTextReader = new StreamReader(ms))
                {
                    PemReader pemReader = new PemReader(privateKeyTextReader, new PasswordFinder(password));
                    AsymmetricCipherKeyPair keyPair = (AsymmetricCipherKeyPair)pemReader.ReadObject();
                    RSA rsa = RSA.Create();

                    

                    RSAParameters rsaParameters = new RSAParameters
                    {
                        Modulus = ((RsaKeyParameters)keyPair.Public).Modulus.ToByteArrayUnsigned(),
                        Exponent = ((RsaKeyParameters)keyPair.Public).Exponent.ToByteArrayUnsigned(),


                        // Modulus = keyPair.Public.GetEncoded(),
                        // Exponent = ((RsaKeyParameters)keyPair.Public).Exponent.ToByteArrayUnsigned(),
                        D = ((RsaPrivateCrtKeyParameters)keyPair.Private).Exponent.ToByteArrayUnsigned(),
                        P = ((RsaPrivateCrtKeyParameters)keyPair.Private).P.ToByteArrayUnsigned(),
                        Q = ((RsaPrivateCrtKeyParameters)keyPair.Private).Q.ToByteArrayUnsigned(),
                        DP = ((RsaPrivateCrtKeyParameters)keyPair.Private).DP.ToByteArrayUnsigned(),
                        DQ = ((RsaPrivateCrtKeyParameters)keyPair.Private).DQ.ToByteArrayUnsigned(),
                    };

                    rsa.ImportParameters(rsaParameters);
                    return (RSACryptoServiceProvider)rsa;
                }
            }
        }

        private class PasswordFinder : IPasswordFinder
        {
            private readonly SecureString password;

            public PasswordFinder(SecureString password)
            {
                this.password = password;
            }

            public char[] GetPassword()
            {
                char[] result = new char[password.Length];
                IntPtr ptr = IntPtr.Zero;

                try
                {
                    ptr = Marshal.SecureStringToGlobalAllocUnicode(password);
                    Marshal.Copy(ptr, result, 0, result.Length);
                }
                finally
                {
                    Marshal.ZeroFreeGlobalAllocUnicode(ptr);
                }

                return result;
            }
        }

            

    }
}

